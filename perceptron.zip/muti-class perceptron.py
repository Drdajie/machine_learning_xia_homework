import matplotlib.pyplot as plt
from numpy import *
import numpy as np

#待分类的类型个数
typeNum = 2;

# Logistic回归梯度上升优化算法
# 读取数据
def loadDataSet():
    dataMat = []
    labelMat = []
    fr = open('./ex4Data/ex4x.dat')
    for line in fr.readlines():
        lineArr = line.strip().split('  ')
        # 为了方便计算，我们将 X0 的值设为 1.0 ，也就是在每一行的开头添加一个 1.0 作为 X0
        dataMat.append([1.0, float(lineArr[0]), float(lineArr[1])])

    fr = open('./ex4Data/ex4y.dat')
    for line in fr.readlines():
        labelMat.append(float(line.strip()))

    dataMatrix = mat(dataMat)

    # Z-score 归一化
    bias, dataMatrix = np.split(dataMatrix, [1], axis=1)
    myMean = dataMatrix.mean(axis=0)
    myStd = dataMatrix.std(axis=0)         #standard deviation
    '''myMax = dataMatrix.max(axis = 0)
    myMin = dataMatrix.min(axis = 0)        '''
    dataMatrix = (dataMatrix - myMean) / myStd
    dataMatrix = np.hstack((bias, dataMatrix))

    dataMat = dataMatrix.tolist()

    return dataMat, labelMat

#其中 ys 为 list，num 为数据个数，其余形参类型都是矩阵
def calculate_loss(realValues,ys,ws,xs,num):
    costValus = 0
    for i in range(num):
        costValus += realValues[i,0] - xs[i] * ws[:,int(ys[i])]
    return costValus

#用 realValues 存储求出的每个种类对应的结果的最大值， hValues 存储最终判断出的种类
def judge_type(inX,ws):
    judgeTool = inX * ws
    num,n = inX.shape
    realValues = mat(np.zeros((num,1)))
    hValues = realValues
    for i in range(num):
        tempList = (judgeTool[i]).tolist()[0]
        realValues[i,0] = max(tempList)
        hValues[i,0] = tempList.index(max(tempList))
    return realValues,hValues


# 输入数据特征与数据的类别标签
# 返回最佳回归系数(weights)
def muti_class_perceptron(dataMatIn, classLabels):
    # 转换为numpy型
    dataMatrix = mat(dataMatIn)

    # 转化为矩阵[[0,1,0,1,0,1.....]]，并转制[[0],[1],[0].....]
    # transpose() 行列转置函数
    # 将行向量转化为列向量   =>  矩阵的转置
    labels = classLabels
    # m->数据量，样本数 n->特征数
    m, n = shape(dataMatrix)
    alpha = 0.001  # 步长
    numIter = 1000  # 迭代次数
    weights = mat(np.ones((n, typeNum)))
    lossValues = []

    #SGD
    for i in range (numIter):
        realValus,hValues = judge_type(dataMatrix,weights)
        # [0, 1, 2 .. m-1]
        dataIndex = range(m)
        # random.uniform(x, y) 方法将随机生成下一个实数，它在[x,y]范围内,x是这个范围内的最小值，y是这个范围内的最大值。
        randIndex = int(random.uniform(0, len(dataIndex)))
        #随机选取更新
        error = 0
        for j in range(typeNum):
            if j == int(hValues[randIndex,0]) and j != int(classLabels[randIndex]):
                error = -1
            elif j != int(hValues[randIndex,0]) and j == int(classLabels[randIndex]):
                error = 1
            weights[:,j] += alpha * error * mat(dataMatrix[randIndex]).transpose()
        del (list(dataIndex)[randIndex])
        lossValues.append(calculate_loss(realValus,classLabels,weights,dataMatrix,m))
    return array(weights),lossValues,numIter


def plotBestFit(ws,dataMat,labelMat):
    #绘制 loss 图
    plt.scatter(range(numIter),lossValues,s=30)
    plt.xlabel("time")
    plt.ylabel("loss")
    plt.show()

    #绘制散点图
    dataArr = array(dataMat)
    # n->数据量，样本数
    n = shape(dataArr)[0]
    # xcord1,ycord1代表正例特征
    # xcord2,ycord2代表负例特征
    xcord1 = [];
    ycord1 = []
    xcord2 = [];
    ycord2 = []

    # 循环筛选出正负集
    toolGet, predictC = judge_type(mat(dataMat), ws)
    rightNum = 0
    for i in range(n):
        if int(labelMat[i]) == 1:
            xcord1.append(dataArr[i, 1]);
            ycord1.append(dataArr[i, 2])
        else:
            xcord2.append(dataArr[i, 1]);
            ycord2.append(dataArr[i, 2])
        if int(predictC[i,0]) == int(labelMat[i]):
            rightNum += 1
    ans = rightNum / n

    # 设定边界直线x和y的值
    # x = arange(-3.0, 3.0, 0.1)
    # print(x)
    axis = [-3, 3, -3, 3]
    plt.axis(axis)
    plt.xlabel('X1')
    plt.ylabel('X2')

    x0, x1 = np.meshgrid(
        np.linspace(axis[0], axis[1], int((axis[1] - axis[0]) * 10)).reshape(-1, 1),
        np.linspace(axis[2], axis[3], int((axis[3] - axis[2]) * 10)).reshape(-1, 1)
    )


    X_new = np.c_[x0.ravel(), x1.ravel()]
    m,n = X_new.shape
    toolColume = np.ones((m,1))
    X_new = np.c_[toolColume,X_new]

    # 2）model.predict(X_new)：将分割出的所有的点，都使用模型预测
    realValues,hValues = judge_type(mat(X_new),ws)
    y_predict = hValues
    # print(y_predict)
    zz = y_predict.reshape(x0.shape)

    # 3）绘制预测结果
    from matplotlib.colors import ListedColormap
    custom_cmap = ListedColormap(['#EF9A9A', '#FFF59D', '#90CAF9'])

    plt.contourf(x0, x1, zz, linewidth=5, cmap=custom_cmap)

    # 4)绘制训练点
    plt.scatter(xcord1, ycord1, s=30, c='red', marker='s')
    plt.scatter(xcord2, ycord2, s=30, c='green')
    plt.show()
    print('正确率：',ans)

dataMat, labelMat = loadDataSet()
print('最后得到的参数为：')
weighs,lossValues,numIter = muti_class_perceptron(mat(dataMat), labelMat)
print(weighs)
plotBestFit(weighs,dataMat, labelMat)
