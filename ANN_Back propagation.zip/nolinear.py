import numpy as np
def sigmods(x):
    return 1/(np.exp(-x)+1)